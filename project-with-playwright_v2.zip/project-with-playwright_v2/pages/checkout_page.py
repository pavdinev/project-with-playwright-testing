# pages/checkout_page.py
from playwright.sync_api import Page

class CheckoutPage:
    def __init__(self, page: Page):
        self.page = page
        self.sel_first = "[data-test='firstName']"
        self.sel_last = "[data-test='lastName']"
        self.sel_zip = "[data-test='postalCode']"
        self.sel_continue = "[data-test='continue']"
        self.sel_cancel = "[data-test='cancel']"
        self.sel_finish = "[data-test='finish']"
        self.sel_error = "[data-test='error']"
        self.sel_overview_item = ".cart_item"
        self.sel_item_total = ".summary_subtotal_label"

    def at_step_one(self) -> bool:
        return self.page.locator(self.sel_first).is_visible()
    

    def enter_info(self, first: str, last: str, zipc: str) -> bool:
        self.page.wait_for_selector(self.sel_first, timeout=5000)
        self.page.fill(self.sel_first, first)
        self.page.fill(self.sel_last, last)
        self.page.fill(self.sel_zip, zipc)
        ok = (
            self.page.input_value(self.sel_first) == first and
            self.page.input_value(self.sel_last) == last and
            self.page.input_value(self.sel_zip) == zipc
        )
        return ok

    def click_continue(self) -> bool:
        self.page.locator(self.sel_continue).click()
        return True

    def click_cancel(self) -> bool:
        self.page.locator(self.sel_cancel).click()
        return True

    def at_overview(self) -> bool:
        return self.page.locator(self.sel_overview_item).count() > 0

    def click_finish(self) -> bool:
        self.page.locator(self.sel_finish).click()
        return True

    def error_visible(self) -> bool:
        return self.page.locator(self.sel_error).is_visible()

    def error_text(self) -> str:
        loc = self.page.locator(self.sel_error)
        return loc.inner_text() if loc.is_visible() else ""

    def overview_item_total(self) -> float:
        text = self.page.locator(self.sel_item_total).inner_text()
        if "$" in text:
            val = text.split("$")[-1]
            return float(val.strip())
        digits = "".join(c for c in text if c.isdigit() or c == '.')
        return float(digits) if digits else 0.0
