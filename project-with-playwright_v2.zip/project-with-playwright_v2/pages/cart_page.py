# pages/cart_page.py
from playwright.sync_api import Page
from utils.smart_scroll import smart_scroll
from typing import List


class CartPage:
    def __init__(self, page: Page):
        self.page = page
        self.cart_items = page.locator(".cart_item")
        self.item_names = page.locator('[data-test="inventory-item-name"]')
        self.item_descriptions = page.locator('[data-test="inventory-item-desc"]')
        self.item_prices = page.locator('[data-test="inventory-item-price"]')
        self.continue_shopping_btn = page.locator("[data-test='continue-shopping']")
        self.checkout_button = page.locator('[data-test="checkout"]')

    def get_item_names(self) -> List[str]:
        try:
            return self.item_names.all_inner_texts()
        except Exception:
            return []

    def get_item_descriptions(self) -> List[str]:
        try:
            return self.item_descriptions.all_inner_texts()
        except Exception:
            return []

    def get_item_prices(self) -> List[str]:
        try:
            return self.item_prices.all_inner_texts()
        except Exception:
            return []

    def continue_shopping(self) -> bool:
        try:
            self.continue_shopping_btn.click()
            return True
        except Exception:
            return False

    def click_checkout(self) -> bool:
        try:
            self.checkout_button.click()
            return True
        except Exception:
            return False

    def scroll_all(self) -> bool:
        return smart_scroll(self.page)
