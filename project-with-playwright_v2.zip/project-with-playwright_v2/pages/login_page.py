from playwright.sync_api import Page
from tests.base_test import BaseTest

class LoginPage:
    """Page Object for the Login page."""

    def __init__(self, page: Page):
        self.page = page
        # Locators
        self.username_input = page.locator("#username")
        self.password_input = page.locator("#password")
        self.login_button = page.locator("#login-button")
        self.error_message = page.locator("h3[data-test='error']")

    # ------------------ Interactions ------------------
    def fill_username(self, username: str) -> bool:
        try:
            self.username_input.fill(username)
            return True
        except Exception:
            return False

    def fill_password(self, password: str) -> bool:
        try:
            self.password_input.fill(password)
            return True
        except Exception:
            return False

    def click_login(self) -> bool:
        try:
            self.login_button.click()
            return True
        except Exception:
            return False

    # ------------------ Checks ------------------
    def is_username_visible(self) -> bool:
        return self.username_input.is_visible()

    def is_password_visible(self) -> bool:
        return self.password_input.is_visible()

    def is_login_button_visible(self) -> bool:
        return self.login_button.is_visible()

    def error_visible(self) -> bool:
        return self.error_message.is_visible()

    def get_error_text(self) -> str:
        return self.error_message.inner_text() if self.error_visible() else ""

    def scroll_all(self) -> bool:
        try:
            BaseTest.smart_scroll(self.page)
            return True
        except Exception:
            return False
    # --- Attribute getters for caching ---
    def get_username_type(self):
        return self.username_input.get_attribute("type")

    def get_password_type(self):
        return self.password_input.get_attribute("type")

    def get_login_button_value(self):
        return self.login_button.get_attribute("value")